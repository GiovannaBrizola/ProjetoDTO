package com.exampleDTO.dto;

public record LivroDTO(Long id, String titulo, String autor)  {

}
