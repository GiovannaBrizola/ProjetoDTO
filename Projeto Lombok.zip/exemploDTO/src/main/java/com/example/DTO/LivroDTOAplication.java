package com.example.DTO;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LivroDTOAplication{
	public static void main(String[] args) {
		SpringApplication.run(LivroDTOAplication.class, args);
	} 

}
