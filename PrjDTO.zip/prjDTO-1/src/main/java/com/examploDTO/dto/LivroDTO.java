package com.examploDTO.dto;

public record LivroDTO (Long id, String titulo, String autor) {

}